
#include "OgreDemoApp.h"
#include "OgreFramework.h"

using namespace Ogre; 

namespace {
	Ogre::Vector3 translateVector;
	float  moveSpeed = 1000; 
	float rotateSpeed = 0.01;
	float timeDelta;
}

DemoApp::DemoApp()
{
	m_pCubeNode = 0;
	m_pCubeEntity = 0;
	m_pSceneMgr = 0;
}

DemoApp::~DemoApp()
{
}

void DemoApp::init()
{
	m_pSceneMgr = OgreFramework::getSingletonPtr()->m_pSceneMgr;
	m_pCamera = OgreFramework::getSingletonPtr()->m_pCamera;
	m_pKeyboard = OgreFramework::getSingletonPtr()->m_pKeyboard;

	m_pCamera->setPosition(Vector3(0, 0, 60));
	m_pCamera->lookAt(Vector3(0, 0, 0));
	m_pCamera->setNearClipDistance(1);

	m_pSceneMgr->setSkyBox(true, "Examples/SpaceSkyBox");
	m_pSceneMgr->createLight("Light")->setPosition(75,75,75);

	m_pCubeEntity = m_pSceneMgr->createEntity("Cube", "ogrehead.mesh");
	m_pCubeNode = m_pSceneMgr->getRootSceneNode()->createChildSceneNode("CubeNode");
	m_pCubeNode->attachObject(m_pCubeEntity);

    Ogre::Entity* ogreHead2 = m_pSceneMgr->createEntity( "Head2", "ogrehead.mesh" );
    Ogre::SceneNode* headNode2 = m_pCubeNode->createChildSceneNode( "HeadNode2", Ogre::Vector3( 100, 0, 0 ) );
    headNode2->attachObject( ogreHead2 );

    Ogre::SceneNode* headNode2Again = m_pSceneMgr->getSceneNode("HeadNode2");
    headNode2Again->translate(Ogre::Vector3(100,0,100));
}

void DemoApp::moveCamera()
{
	if(m_pKeyboard->isKeyDown(OIS::KC_LSHIFT)) 
		m_pCamera->moveRelative(translateVector);
	else
		m_pCamera->moveRelative(translateVector / 10);
}

void DemoApp::getInput()
{
    if(m_pKeyboard->isKeyDown(OIS::KC_LEFT)) {
		translateVector.x = - moveSpeed*timeDelta;
	}
	if(m_pKeyboard->isKeyDown(OIS::KC_RIGHT)) {
		translateVector.x =  moveSpeed*timeDelta;
	}
	if(m_pKeyboard->isKeyDown(OIS::KC_UP)) {
		translateVector.z = - moveSpeed*timeDelta;
	}
	if(m_pKeyboard->isKeyDown(OIS::KC_DOWN)) {
		translateVector.z =  moveSpeed*timeDelta;
	}
}

void DemoApp::run()
{
	translateVector = Vector3::ZERO;
	timeDelta = (Ogre::Real)OgreFramework::getSingletonPtr()->mLastFrameTime;
	getInput();
	moveCamera();
}

// input
bool DemoApp::keyPressed(const OIS::KeyEvent &keyEventRef)
{
	OgreFramework::getSingletonPtr()->keyPressed(keyEventRef);
	if(OgreFramework::getSingletonPtr()->m_pKeyboard->isKeyDown(OIS::KC_F)) {
        //do something
	}
	return true;
}

bool DemoApp::keyReleased(const OIS::KeyEvent &keyEventRef)
{
	OgreFramework::getSingletonPtr()->keyReleased(keyEventRef);
	return true;
}

void DemoApp::mouseMoved(const OIS::MouseEvent &evt)
{
	m_pCamera->yaw(Degree(- evt.state.X.rel * rotateSpeed));
	m_pCamera->pitch(Degree(evt.state.Y.rel * rotateSpeed));
}

void DemoApp::mousePressed(const OIS::MouseEvent &evt, OIS::MouseButtonID id)
{
}

void DemoApp::mouseReleased(const OIS::MouseEvent &evt, OIS::MouseButtonID id)
{
}