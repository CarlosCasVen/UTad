#include "OgreFramework.h"

#include <stdio.h>  /* defines FILENAME_MAX */

#if OGRE_PLATFORM == PLATFORM_WIN32 || OGRE_PLATFORM == OGRE_PLATFORM_WIN32
    #include <direct.h>
    #define GetCurrentDir _getcwd
#else
    #include <unistd.h>
    #define GetCurrentDir getcwd
 #endif

#include "OgreDemoApp.h"

//#include "macUtils.h"

using namespace Ogre; 

namespace Ogre
{
    template<> OgreFramework* Ogre::Singleton<OgreFramework>::msSingleton = 0;
	String bundlePath() {
#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
    char path[FILENAME_MAX];

    if (!GetCurrentDir(path, sizeof(path))) {
         return "";
    }
    path[sizeof(path) - 1] = '\0'; /* not really required */

	LogLine("CurrentDir:%s",path)

    //char str[512];
    //sprintf(str, "CurrentDir:%s",path);
    //OutputDebugString(str);

	return "..\\";
#else
		return macBundlePath() + "/"
#endif
	}
};

OgreFramework::OgreFramework()
{   
	m_bShutDownOgre     = false;
	m_iNumScreenShots   = 0;
    
	m_pRoot				= 0;
	m_pSceneMgr			= 0;
	m_pRenderWnd        = 0;
	m_pCamera			= 0;
	m_pViewport			= 0;
	m_pLog				= 0;
	m_pTimer			= 0;
    
	m_pInputMgr			= 0;
	m_pKeyboard			= 0;
	m_pMouse			= 0;


    //m_pTrayMgr          = 0;
    m_FrameEvent        = Ogre::FrameEvent();
	m_demo = 0;
}

OgreFramework::~OgreFramework()
{
    if(m_pInputMgr) OIS::InputManager::destroyInputSystem(m_pInputMgr);
    //if(m_pTrayMgr)  delete m_pTrayMgr;
    if(m_pRoot)     delete m_pRoot;
}

bool OgreFramework::initOgre(Ogre::String wndTitle, OIS::KeyListener *pKeyListener, OIS::MouseListener *pMouseListener)
{
    new Ogre::LogManager();

	m_pLog = Ogre::LogManager::getSingleton().createLog("OgreLogfile.log", true, true, false);
	m_pLog->setDebugOutputEnabled(true);
    

    // only use plugins.cfg if not static

#ifdef _DEBUG
    mResourcesCfg = "resources_d.cfg";
    mPluginsCfg = "plugins_d.cfg";
    mOgreCfg = "ogre.cfg";
#else
    mResourcesCfg = "resources.cfg";
    mPluginsCfg = "plugins.cfg";
    mOgreCfg = "ogre.cfg";
#endif

    String pluginsFile = bundlePath() + mPluginsCfg;
    String resourceFile = bundlePath() + mResourcesCfg;
    String ogreConfigFile = bundlePath() + mOgreCfg;
    
	LogLine("Resorces:%s", resourceFile.c_str());
    //m_pRoot = new Ogre::Root(pluginsPath, bundlePath() + "ogre.cfg");
    m_pRoot = new Ogre::Root(pluginsFile, ogreConfigFile);
    
	if(!m_pRoot->showConfigDialog())
		return false;

//#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
//        HWND hwnd;
//        mWindow->getCustomAttribute("WINDOW", (void*)&hwnd);
//        LONG iconID   = (LONG)LoadIcon( GetModuleHandle(0), MAKEINTRESOURCE(IDI_APPICON) );
//        SetClassLong( hwnd, GCL_HICON, iconID );
//#endif

    m_pRoot->restoreConfig();
	m_pRenderWnd = m_pRoot->initialise(true, wndTitle);
    
	unsigned long hWnd = 0;
    OIS::ParamList paramList;
    m_pRenderWnd->getCustomAttribute("WINDOW", &hWnd);
    
#if OGRE_PLATFORM == PLATFORM_WIN32 || OGRE_PLATFORM == OGRE_PLATFORM_WIN32
	paramList.insert(OIS::ParamList::value_type("WINDOW", Ogre::StringConverter::toString(hWnd)));
    paramList.insert(std::make_pair(std::string("w32_mouse"), std::string("DISCL_FOREGROUND" )));
    paramList.insert(std::make_pair(std::string("w32_mouse"), std::string("DISCL_NONEXCLUSIVE")));
    paramList.insert(std::make_pair(std::string("w32_keyboard"), std::string("DISCL_FOREGROUND")));
    paramList.insert(std::make_pair(std::string("w32_keyboard"), std::string("DISCL_NONEXCLUSIVE")));
	m_pInputMgr = OIS::InputManager::createInputSystem(paramList);
#endif

    m_pKeyboard = static_cast<OIS::Keyboard*>(m_pInputMgr->createInputObject(OIS::OISKeyboard, true));
	m_pMouse = static_cast<OIS::Mouse*>(m_pInputMgr->createInputObject(OIS::OISMouse, true));
    
	m_pMouse->getMouseState().height = m_pRenderWnd->getHeight();
	m_pMouse->getMouseState().width	 = m_pRenderWnd->getWidth();
    
	if(pKeyListener == 0)
		m_pKeyboard->setEventCallback(this);
	else
		m_pKeyboard->setEventCallback(pKeyListener);
    
	if(pMouseListener == 0)
		m_pMouse->setEventCallback(this);
	else
		m_pMouse->setEventCallback(pMouseListener);
    
	setupResources();

	Ogre::TextureManager::getSingleton().setDefaultNumMipmaps(5);
	Ogre::ResourceGroupManager::getSingleton().initialiseAllResourceGroups();
    
	m_pTimer = OGRE_NEW Ogre::Timer();
	m_pTimer->reset();
	
	//m_pTrayMgr = new OgreBites::SdkTrayManager("TrayMgr", m_pRenderWnd, m_pMouse, this);
 //   m_pTrayMgr->showFrameStats(OgreBites::TL_TOPLEFT);
 //   m_pTrayMgr->showLogo(OgreBites::TL_BOTTOMRIGHT);
 //   m_pTrayMgr->hideCursor();
    
	m_pRenderWnd->setActive(true);

	m_pSceneMgr = m_pRoot->createSceneManager(ST_GENERIC, "SceneManager");
	m_pSceneMgr->setAmbientLight(Ogre::ColourValue(0.7f, 0.7f, 0.7f));

	m_demo = new DemoApp();
	
	m_pCamera = m_pSceneMgr->createCamera("Camera");

	m_pViewport = m_pRenderWnd->addViewport(m_pCamera);
	m_pViewport->setBackgroundColour(ColourValue(0.8f, 0.7f, 0.6f, 1.0f));
    
	m_pCamera->setAspectRatio(Real(m_pViewport->getActualWidth()) / Real(m_pViewport->getActualHeight()));
	
	m_pViewport->setCamera(m_pCamera);

    m_pRoot->addFrameListener(this);

	m_demo->init();

	mStartTime = m_pTimer->getMillisecondsCPU();
	return true;
}


void OgreFramework::setupResources() 
{
	Ogre::String secName, typeName, archName;
	Ogre::ConfigFile cf;
    cf.load(bundlePath() + mResourcesCfg);
    
	Ogre::ConfigFile::SectionIterator seci = cf.getSectionIterator();
    while (seci.hasMoreElements())
    {
        secName = seci.peekNextKey();
		Ogre::ConfigFile::SettingsMultiMap *settings = seci.getNext();
        Ogre::ConfigFile::SettingsMultiMap::iterator i;
        for (i = settings->begin(); i != settings->end(); ++i)
        {
            typeName = i->first;
            archName = i->second;

            // OS X does not set the working directory relative to the app,
            // In order to make things portable on OS X we need to provide
            // the loading with it's own bundle path location
            if (!Ogre::StringUtil::startsWith(archName, "/", false)) // only adjust relative dirs
                archName = Ogre::String(bundlePath() + archName);
            Ogre::ResourceGroupManager::getSingleton().addResourceLocation(archName, typeName, secName);
        }
    }
}

void OgreFramework::updateOgre(double timeSinceLastFrame)
{
#if OGRE_VERSION >= 0x10800
    m_pSceneMgr->setSkyBoxEnabled(true);
#endif
    
	m_demo->run();

	m_FrameEvent.timeSinceLastFrame = (Ogre::Real) timeSinceLastFrame;
    //m_pTrayMgr->frameRenderingQueued(m_FrameEvent);
}

bool OgreFramework::frameStarted(const Ogre::FrameEvent& evt)
{
    return true;
}
bool OgreFramework::frameEnded(const Ogre::FrameEvent& evt)
{
    return true;
}

bool OgreFramework::frameRenderingQueued(const Ogre::FrameEvent& evt)
{

    if(!isOgreToBeShutDown() && Ogre::Root::getSingletonPtr() && Ogre::Root::getSingleton().isInitialised()) {

		if(m_pRenderWnd->isActive()) {

			mLastFrameTime = (m_pTimer->getMillisecondsCPU() - mStartTime)*1e-3;
            
			m_pKeyboard->capture();
			m_pMouse->capture();
			updateOgre(mLastFrameTime*1e-3);

			mStartTime = m_pTimer->getMillisecondsCPU();
		}
    }
    else
    {
        return false;
    }

    return true;
}


bool OgreFramework::keyPressed(const OIS::KeyEvent &keyEventRef)
{
	
	if(m_pKeyboard->isKeyDown(OIS::KC_ESCAPE))
	{
        m_bShutDownOgre = true;
        return true;
	}
    
	if(m_pKeyboard->isKeyDown(OIS::KC_SYSRQ))
	{
		m_pRenderWnd->writeContentsToTimestampedFile("BOF_Screenshot_", ".png");
		return true;
	}
    
	if(m_pKeyboard->isKeyDown(OIS::KC_M))
	{
		static int mode = 0;
		
		if(mode == 2)
		{
			m_pCamera->setPolygonMode(PM_SOLID);
			mode = 0;
		}
		else if(mode == 0)
		{
            m_pCamera->setPolygonMode(PM_WIREFRAME);
            mode = 1;
		}
		else if(mode == 1)
		{
			m_pCamera->setPolygonMode(PM_POINTS);
			mode = 2;
		}
	}
    
	//if(m_pKeyboard->isKeyDown(OIS::KC_O))
	//{
	//	if(m_pTrayMgr->isLogoVisible())
 //       {
 //           m_pTrayMgr->hideLogo();
 //           m_pTrayMgr->hideFrameStats();
 //       }
 //       else
 //       {
 //           m_pTrayMgr->showLogo(OgreBites::TL_BOTTOMRIGHT);
 //           m_pTrayMgr->showFrameStats(OgreBites::TL_BOTTOMLEFT);
 //       }
	//}

	return true;
}

bool OgreFramework::keyReleased(const OIS::KeyEvent &keyEventRef)
{
	return true;
}

//|||||||||||||||||||||||||||||||||||||||||||||||

bool OgreFramework::mouseMoved(const OIS::MouseEvent &evt)
{
	m_demo->mouseMoved(evt);	
	return true;
}

bool OgreFramework::mousePressed(const OIS::MouseEvent &evt, OIS::MouseButtonID id)
{
	m_demo->mousePressed(evt, id);
	return true;
}

bool OgreFramework::mouseReleased(const OIS::MouseEvent &evt, OIS::MouseButtonID id)
{
	m_demo->mouseReleased(evt, id);
	return true;
}


