
#include "OgreDemoApp.h"
#include "OgreFramework.h"
#include "EulerAngles.h"

using namespace Ogre; 

namespace {
	Ogre::Vector3 translateVector;
	float  moveSpeed = 1000; 
	float rotateSpeed = 0.01;
	float timeDelta;
	

	///VAR GLOBALES
	Vector3 initialPosition(0,0,0);
	Vector3 posCamera(0, 50, 200);
	Vector3 cameraPosition(posCamera);
	Euler  cameraOrientationAngles;
	Degree  cameraFOV = Degree( 45 );
	bool    freeCamera = false;
	bool    m_smooth   = true;
	int     m_pressed  = 0;
	float   m_time     = 0;
	float   smoothFactor;
	Vector3 targetOffset, smoothTargetOffset;
	Node*   m_target;
}

DemoApp::DemoApp()
{
	m_pCubeNode   = 0;
	m_pCubeEntity = 0;
	m_pSceneMgr   = 0;
	cameraOrientationAngles = NULL;
	smoothFactor = 0.01f;
	m_target = NULL;
}

DemoApp::~DemoApp()
{
	
}

//FUNCIONES NUEVAS
SceneNode* createGridPlane(SceneManager* scene, SceneNode* rootNode, Vector3 position){
	//Crea el plano
	Plane plane;
	plane.normal = Vector3::UNIT_Y;
	plane.d = 0;
	
	Ogre::MeshPtr plane_mesh = MeshManager::getSingleton().createPlane("floor", ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME, plane, 400, 400, 10, 10, true, 1, 2, 2, Vector3::UNIT_Z);

	Ogre::Entity* plane_entity = scene->createEntity("plane", plane_mesh);
	rootNode = scene->getRootSceneNode()->createChildSceneNode("plane");
	rootNode->attachObject(plane_entity);
	rootNode->translate(position);

	return rootNode;
}

SceneNode* createCube(SceneManager* scene, SceneNode* parent, Vector3 position, const String& name, const String& material, const Vector3& scale){
	//Crea el cubo
	Ogre::Entity* cube_entity = scene->createEntity(name, "cube.mesh");
	parent = scene->getRootSceneNode()->createChildSceneNode(name);
	parent->attachObject(cube_entity);
	parent->setScale(scale);
	parent->translate(position);
	cube_entity->setMaterialName(material);

	return parent;
}



void DemoApp::init()
{	
	m_pSceneMgr = OgreFramework::getSingletonPtr()->m_pSceneMgr;
	m_pCamera   = OgreFramework::getSingletonPtr()->m_pCamera;
	m_pKeyboard = OgreFramework::getSingletonPtr()->m_pKeyboard;

	m_pCamera->setPosition(cameraPosition);
	m_pCamera->lookAt(initialPosition);
	m_pCamera->setNearClipDistance(1);

	m_pSceneMgr->setSkyBox(true, "Examples/SpaceSkyBox");
	m_pSceneMgr->createLight("Light")->setPosition(75,75,75);


	Vector3 scale = Vector3(0.5, 0.5, 0.5);

	Vector3 posLeft   = Vector3(-50, 0, 0);
	Vector3 posCenter = Vector3(0, 0, 0);	
	Vector3 posRight  = Vector3(50, 0, 0);	

	createCube( m_pSceneMgr, m_pCubeNode, posLeft  , "CubeLeft" , "Cube/RedMesh"  , scale );	
	createCube( m_pSceneMgr, m_pCubeNode, posCenter, "CubeMid"  , "Cube/BlueMesh" , scale );	
	createCube( m_pSceneMgr, m_pCubeNode, posRight , "CubeRight", "Cube/WhiteMesh", scale );

	createGridPlane( m_pSceneMgr, m_pCubeNode, posCenter );

}

void DemoApp::moveCamera()
{
	Ogre::Radian min = Ogre::Radian( Ogre::Math::DegreesToRadians( 20 ) );
	Ogre::Radian max = Ogre::Radian( Ogre::Math::DegreesToRadians( 90 ) );
	Ogre::Radian inc = Ogre::Radian( Ogre::Math::DegreesToRadians( 1  ) );

	if		( m_pKeyboard->isKeyDown( OIS::KC_I ) && ( m_pCamera->getFOVy() > min + inc ) )	m_pCamera->setFOVy(m_pCamera->getFOVy() - inc * 0.1); //multiplico por 0.1 para que se aprecie el zoom
	else if ( m_pKeyboard->isKeyDown( OIS::KC_O ) && ( m_pCamera->getFOVy() < max - inc ) )	m_pCamera->setFOVy(m_pCamera->getFOVy() + inc * 0.1); //multiplico por 0.1 para que se aprecie el zoom

	if( m_pKeyboard->isKeyDown( OIS::KC_LSHIFT ) )											m_pCamera->moveRelative( translateVector      );
	else																					m_pCamera->moveRelative( translateVector / 10 );

	smoothTargetOffset += ( targetOffset - smoothTargetOffset ) * smoothFactor;
	
	if( !freeCamera )
	{
		m_pCamera->lookAt( smoothTargetOffset );
		if( m_target ) targetOffset = m_target->getPosition();
	}
}

void DemoApp::getInput()
{
    if(m_pKeyboard->isKeyDown(OIS::KC_LEFT)) {
		translateVector.x = - moveSpeed*timeDelta;
	}
	if(m_pKeyboard->isKeyDown(OIS::KC_RIGHT)) {
		translateVector.x =  moveSpeed*timeDelta;
	}
	if(m_pKeyboard->isKeyDown(OIS::KC_UP)) {
		translateVector.z = - moveSpeed*timeDelta;
	}
	if(m_pKeyboard->isKeyDown(OIS::KC_DOWN)) {
		translateVector.z =  moveSpeed*timeDelta;
	}


}

void DemoApp::run()
{
	translateVector = Vector3::ZERO;
	timeDelta = (Ogre::Real)OgreFramework::getSingletonPtr()->mLastFrameTime;
	getInput();
	moveCamera();
	m_time += timeDelta;

	Ogre::Node* cubeNode = m_pSceneMgr->getEntity( "CubeRight" )->getParentNode();
	cubeNode->setPosition( cubeNode->getPosition() + Ogre::Vector3( 0, Ogre::Math::Sin( m_time ) / 20 ,0 ) );

}


bool DemoApp::keyPressed(const OIS::KeyEvent &keyEventRef )
{	 
	if(OgreFramework::getSingletonPtr()->m_pKeyboard->isKeyDown(OIS::KC_T)) {
        
	

		switch ( m_pressed )
		{
		case 0:
			m_target =  m_pSceneMgr->getEntity("CubeLeft")->getParentNode();
			targetOffset = m_target->getPosition();
			freeCamera = false;
			break;
		case 1:
			m_target =  m_pSceneMgr->getEntity("CubeMid")->getParentNode();
			smoothTargetOffset = targetOffset = m_target->getPosition();
			break;
		case 2:		
			m_target =  m_pSceneMgr->getEntity("CubeRight")->getParentNode();
			targetOffset = m_target->getPosition();
			freeCamera = false;
			break;					
		case 3:
			freeCamera = true;	
			break;
		}
		m_pressed = ( m_pressed + 1 ) % 4;	
	}
	return true;
}

bool DemoApp::keyReleased(const OIS::KeyEvent &keyEventRef)
{
	return true;
}

void DemoApp::mouseMoved(const OIS::MouseEvent &evt)
{
	Ogre::Radian limitAngle = (Ogre::Radian)20 * Ogre::Math::PI / 180;
	cameraOrientationAngles.yaw((Ogre::Radian)Degree(- evt.state.X.rel * rotateSpeed));
	cameraOrientationAngles.pitch((Ogre::Radian)Degree(evt.state.Y.rel * rotateSpeed));
	cameraOrientationAngles.limitYaw(limitAngle);
	cameraOrientationAngles.limitPitch(limitAngle);
	m_pCamera->setOrientation(cameraOrientationAngles.toQuaternion());
}

void DemoApp::mousePressed(const OIS::MouseEvent &evt, OIS::MouseButtonID id)
{
}

void DemoApp::mouseReleased(const OIS::MouseEvent &evt, OIS::MouseButtonID id)
{
}