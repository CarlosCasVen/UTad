

#ifndef OGRE_DEMO_H
#define OGRE_DEMO_H

#include "OgreFramework.h"
#include <OgreMeshManager.h>

class DemoApp : public OIS::KeyListener
{
private:
	Ogre::SceneManager*	m_pSceneMgr;
	Ogre::Camera* m_pCamera;
	Ogre::SceneNode* m_pCubeNode;
	Ogre::Entity* m_pCubeEntity;
	OIS::Keyboard*	m_pKeyboard;

public:
	DemoApp();
	~DemoApp();
    
	void init();
	void run();
	
	// input
	bool keyPressed(const OIS::KeyEvent &keyEventRef);
	bool keyReleased(const OIS::KeyEvent &keyEventRef);
    void mouseMoved(const OIS::MouseEvent &evt);
	void mousePressed(const OIS::MouseEvent &evt, OIS::MouseButtonID id);
	void mouseReleased(const OIS::MouseEvent &evt, OIS::MouseButtonID id);

private:
	void getInput();
	void moveCamera();

};

#endif 
